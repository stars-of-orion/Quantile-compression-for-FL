#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @python: 3.6

import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader


# Set the device to GPU if available, otherwise CPU************************
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def test_img(net_g, datatest, args):
    net_g.eval()
    net_g.to(device)  # Move the model to the appropriate device******************
    # testing
    test_loss = 0
    correct = 0
    data_loader = DataLoader(datatest, batch_size=args.bs)
    l = len(data_loader)
    for idx, (data, target) in enumerate(data_loader):
        # Move data and target to the appropriate device (GPU or CPU)**************
        data, target = data.to(device), target.to(device)

        log_probs = net_g(data)
        # sum up batch loss
        test_loss += F.cross_entropy(log_probs, target, reduction='sum').item()
        # get the index of the max log-probability
        y_pred = log_probs.data.max(1, keepdim=True)[1]
        correct += y_pred.eq(target.data.view_as(y_pred)).long().cpu().sum()

    test_loss /= len(data_loader.dataset)
    accuracy = 100.00 * correct / len(data_loader.dataset)
    if args.verbose:
        print('\nTest set: Average loss: {:.4f} \nAccuracy: {}/{} ({:.2f}%)\n'.format(
            test_loss, correct, len(data_loader.dataset), accuracy))
    return accuracy, test_loss

import os

def file_store(acc_train, loss_train, acc_test, loss_test):
    # Get the directory where the script is located
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create a folder named 'Model1' in the same directory if it doesn't exist
    model_dir = os.path.join(base_dir, 'VGGModelCifarWith')
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    
    # Create file paths inside the 'VGGModelCifarWith' folder
    acc_train_path = os.path.join(model_dir, 'acc_train.txt')
    loss_train_path = os.path.join(model_dir, 'loss_train.txt')
    acc_test_path = os.path.join(model_dir, 'acc_test.txt')
    loss_test_path = os.path.join(model_dir, 'loss_test.txt')
    
    # Save the accuracy and loss data to respective files inside the 'Model1' folder
    with open(acc_train_path, 'w') as f: 
        for i in acc_train: 
            f.write(str(i) + "\n")
            
    with open(loss_train_path, 'w') as f: 
        for i in loss_train: 
            f.write(str(i) + "\n")
            
    with open(acc_test_path, 'w') as f: 
        for i in acc_test: 
            f.write(str(i) + "\n")
            
    with open(loss_test_path, 'w') as f: 
        for i in loss_test: 
            f.write(str(i) + "\n")