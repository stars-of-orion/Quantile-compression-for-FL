#!/bin/sh

python test.py

python fed_OQFL.py

echo "Done VGGCIFAR"

python fed_OQFLMnist.py

echo "Done VGGMNIST"

python fed_OQFLResCif.py

echo "Done ResCIFAR"

python fed_OQFLResMnist.py

echo "Done ResMnist" 
